/* List of paths to images */
var posters = [
	"star-wars.jpg",
	"inception.jpg",
	"stitch.jpg",
	"lotr.jpg",
	"kuzco.jpg"
];

/* Keep track of the index of the current movie */
var currMovie = 0;

function changeMovie() {
	/* Increment the index of the current movie */
	currMovie++;
	
	/* Mod currMovie by the number of posters */
	var index = currMovie % posters.length;
	
	/* Set the img source using the list of
	   poster names */
	var imgSrc = "img/" + posters[index];
	document.getElementById("poster").src = imgSrc;
}