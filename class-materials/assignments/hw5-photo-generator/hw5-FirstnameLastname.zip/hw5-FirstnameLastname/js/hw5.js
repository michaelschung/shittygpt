// Use this array to store the filenames of the favorite photos
var favs = [];